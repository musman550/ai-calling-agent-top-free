"""
utils/tools.py
----------------
Structured function-calling — how the LLM takes real actions (book,
transfer, take a message, hang up) instead of us guessing at keywords
in free text. This is the same mechanism Vapi/Retell/Bland use, built
here on Pipecat's own documented, provider-agnostic tool-calling API
(FunctionSchema / ToolsSchema / FunctionCallParams), so it works
against Groq's tool-calling support without any custom glue code.

Reference: https://docs.pipecat.ai/guides/fundamentals/function-calling

Usage from bot.py, per call:
    tools_schema = build_tools_schema()
    context = LLMContext(messages=messages, tools=tools_schema)
    ...
    for name, handler in make_tool_handlers(call_logger, on_end_call, on_transfer).items():
        llm.register_function(name, handler)
"""

import asyncio
import logging

from pipecat.adapters.schemas.function_schema import FunctionSchema
from pipecat.adapters.schemas.tools_schema import ToolsSchema
from pipecat.frames.frames import FunctionCallResultProperties
from pipecat.services.llm_service import FunctionCallParams

from utils.booking import send_booking, record_message
from utils.sms_followup import send_followup_sms

logger = logging.getLogger("ai_calling_agent.tools")


def build_tools_schema() -> ToolsSchema:
    """Defines the four actions the agent can take. Add more here as your
    clients need them (e.g. check_availability, cancel_appointment) —
    just follow the same FunctionSchema shape and add a matching handler
    in make_tool_handlers() below."""

    book_appointment = FunctionSchema(
        name="book_appointment",
        description=(
            "Book an appointment once the caller has given their name, a "
            "contact number, and a preferred date/time. Only call this "
            "after confirming the details back to the caller out loud."
        ),
        properties={
            "name": {"type": "string", "description": "Caller's full name"},
            "phone": {"type": "string", "description": "Caller's phone number"},
            "preferred_time": {
                "type": "string",
                "description": "Requested date/time, in the caller's own words",
            },
            "reason": {"type": "string", "description": "What the appointment is for"},
        },
        required=["name", "phone", "preferred_time"],
    )

    transfer_to_human = FunctionSchema(
        name="transfer_to_human",
        description=(
            "Transfer the call to a human team member. Use this when the "
            "caller explicitly asks for a person, is upset, or has a "
            "request outside what you're able to help with."
        ),
        properties={
            "reason": {
                "type": "string",
                "description": "Short reason for the transfer, for the human's context",
            }
        },
        required=["reason"],
    )

    take_message = FunctionSchema(
        name="take_message",
        description=(
            "Take a message for the business when no one is available or "
            "the caller doesn't want to book or be transferred."
        ),
        properties={
            "name": {"type": "string", "description": "Caller's name"},
            "phone": {"type": "string", "description": "Caller's phone number, if given"},
            "message": {"type": "string", "description": "What they want passed along"},
        },
        required=["name", "message"],
    )

    end_call = FunctionSchema(
        name="end_call",
        description=(
            "End the call gracefully. Only call this immediately after "
            "you have already said a proper goodbye to the caller."
        ),
        properties={},
        required=[],
    )

    return ToolsSchema(
        standard_tools=[book_appointment, transfer_to_human, take_message, end_call]
    )


def make_tool_handlers(call_logger, on_end_call, on_transfer):
    """Returns {tool_name: handler} for this specific call, closing over
    the call's own logger and callbacks so multiple simultaneous calls
    never share state."""

    async def handle_book_appointment(params: FunctionCallParams):
        args = params.arguments
        try:
            ok = await send_booking(
                name=args.get("name", ""),
                phone=args.get("phone", ""),
                preferred_time=args.get("preferred_time", ""),
                reason=args.get("reason", ""),
            )
            if call_logger:
                call_logger.append("system", f"book_appointment({args}) -> {ok}")
            if ok:
                await params.result_callback(
                    {"status": "booked", "message": "Booking recorded successfully."}
                )
            else:
                await params.result_callback(
                    {
                        "status": "failed",
                        "message": (
                            "Booking system isn't reachable right now — tell the "
                            "caller you'll confirm shortly and take a message instead."
                        ),
                    }
                )
        except Exception as exc:  # noqa: BLE001 - a broken tool must not break the call
            logger.error(f"book_appointment failed: {exc}")
            await params.result_callback(
                {"status": "error", "message": "That didn't go through — apologize and offer to take a message."}
            )

    async def handle_transfer_to_human(params: FunctionCallParams):
        args = params.arguments
        reason = args.get("reason", "")
        try:
            if call_logger:
                call_logger.append("system", f"transfer_to_human(reason={reason})")
            if on_transfer:
                ok = await on_transfer(reason)
                msg = "Transfer initiated." if ok else "Transfer isn't set up for this line yet — take a message instead."
                # On success the call is redirected immediately, so the LLM must not talk again.
                await params.result_callback(
                    {"status": "ok" if ok else "unavailable", "message": msg},
                    properties=FunctionCallResultProperties(run_llm=not ok),
                )
            else:
                await params.result_callback(
                    {"status": "unavailable", "message": "Transfers aren't available on this channel — take a message instead."}
                )
        except Exception as exc:  # noqa: BLE001
            logger.error(f"transfer_to_human failed: {exc}")
            await params.result_callback({"status": "error", "message": "Transfer failed — take a message instead."})

    async def handle_take_message(params: FunctionCallParams):
        args = params.arguments
        try:
            if call_logger:
                call_logger.append("system", f"take_message({args})")
            phone = args.get("phone")
            if phone:
                await asyncio.to_thread(
                    send_followup_sms, phone,
                    "Thanks for calling — we've got your message and will follow up shortly.",
                )
            record_message(args.get("name", ""), phone or "", args.get("message", ""))
            await params.result_callback({"status": "ok", "message": "Message recorded."})
        except Exception as exc:  # noqa: BLE001
            logger.error(f"take_message failed: {exc}")
            await params.result_callback({"status": "error", "message": "Couldn't save the message, apologize briefly."})

    async def handle_end_call(params: FunctionCallParams):
        try:
            # run_llm=False: the goodbye was already said; don't let the model speak again.
            await params.result_callback(
                {"status": "ok", "message": "Call ending."},
                properties=FunctionCallResultProperties(run_llm=False),
            )
            if on_end_call:
                await on_end_call()
        except Exception as exc:  # noqa: BLE001
            logger.error(f"end_call failed: {exc}")

    return {
        "book_appointment": handle_book_appointment,
        "transfer_to_human": handle_transfer_to_human,
        "take_message": handle_take_message,
        "end_call": handle_end_call,
    }
