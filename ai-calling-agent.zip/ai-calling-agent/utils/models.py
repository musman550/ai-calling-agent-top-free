"""
utils/models.py — asks Groq which models YOUR key can actually use, and picks the best ones.
Hard-coded model names caused 404 "model_not_found" for some accounts; this removes that failure.
"""
import json
import urllib.request

ORPHEUS_VOICES = {"autumn", "diana", "hannah", "austin", "daniel", "troy"}


def fetch_models(key: str, timeout: int = 15):
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/models",
        headers={"Authorization": f"Bearer {key}", "User-Agent": "ai-calling-agent"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return sorted(m["id"] for m in json.load(r)["data"])


def _pref(items, preferred):
    return next((p for p in preferred if p in items), items[0] if items else None)


def pick_models(ids):
    low = lambda i: i.lower()
    is_stt = lambda i: "whisper" in low(i)
    is_tts = lambda i: any(x in low(i) for x in ("tts", "orpheus", "playai"))
    chat = [i for i in ids if not is_stt(i) and not is_tts(i) and "guard" not in low(i)]
    stt = [i for i in ids if is_stt(i)]
    tts = [i for i in ids if is_tts(i)]
    return {
        "llm": _pref(chat, ["llama-3.3-70b-versatile", "openai/gpt-oss-120b", "llama-3.1-8b-instant", "openai/gpt-oss-20b"]),
        "stt": _pref(stt, ["whisper-large-v3-turbo", "whisper-large-v3"]),
        "tts": tts[0] if tts else None,
    }


def apply_models(env, ids):
    """Fill GROQ_*_MODEL / voice in `env` only where the current value is missing or NOT available
    to this key. Returns a list of human-readable notes."""
    picked, notes = pick_models(ids), []
    for var, kind in (("GROQ_LLM_MODEL", "llm"), ("GROQ_STT_MODEL", "stt"), ("GROQ_TTS_MODEL", "tts")):
        cur = env.get(var, "")
        if picked[kind] and cur not in ids:
            env[var] = picked[kind]
            notes.append(f"{kind.upper()} -> {picked[kind]}" + (f" (was '{cur}', not available to your key)" if cur else ""))
        elif not picked[kind]:
            notes.append(f"! no {kind.upper()} model available to this key")
    tts, voice = env.get("GROQ_TTS_MODEL", ""), env.get("GROQ_TTS_VOICE", "")
    if "orpheus" in tts.lower() and voice.lower() not in ORPHEUS_VOICES:
        env["GROQ_TTS_VOICE"] = "hannah"
    elif "playai" in tts.lower() and not voice.endswith("-PlayAI"):
        env["GROQ_TTS_VOICE"] = "Fritz-PlayAI"
    return notes
