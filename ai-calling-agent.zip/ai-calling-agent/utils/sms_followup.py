"""
utils/sms_followup.py
-----------------------
Optional: send a short SMS after the call ends (e.g. booking confirmation,
"thanks for calling", or a link). Uses Twilio, so it only works once a
client has a real Twilio number set up (see README "Telephony Reality
Check"). SMS is billed per-message on Twilio's pay-as-you-go pricing —
this is a premium add-on to offer, not a free-tier default.
"""

import logging

from twilio.rest import Client

import config

logger = logging.getLogger("ai_calling_agent.sms")


def send_followup_sms(to_number: str, message: str) -> bool:
    if not (config.TWILIO_ACCOUNT_SID and config.TWILIO_AUTH_TOKEN and config.TWILIO_PHONE_NUMBER):
        logger.warning("Twilio credentials not fully set — skipping SMS follow-up.")
        return False

    try:
        client = Client(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)
        client.messages.create(
            to=to_number,
            from_=config.TWILIO_PHONE_NUMBER,
            body=message,
        )
        logger.info(f"Follow-up SMS sent to {to_number}")
        return True
    except Exception as exc:  # noqa: BLE001 - never let SMS failure break the call flow
        logger.error(f"SMS follow-up failed: {exc}")
        return False
