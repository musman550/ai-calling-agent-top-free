"""
utils/call_logger.py
---------------------
Saves a call's transcript + a note of every tool action taken to a JSON
file, so you can show clients a "call report."

Reads directly from the LLMContext's own message list at the end of the
call rather than tapping individual audio/text frames mid-pipeline —
the context is already the single source of truth Pipecat maintains
for the conversation, so this is both simpler and less likely to ever
get out of sync with what was actually said.
"""

import json
import datetime as dt
from pathlib import Path

import config


class CallLogger:
    def __init__(self, call_id: str):
        self.call_id = call_id
        self.started_at = dt.datetime.now(dt.timezone.utc).isoformat()
        self.system_events = []  # tool calls, transfers, etc — appended live

    def append(self, kind: str, text: str):
        """Records a non-conversation event (a tool call result, a
        transfer, etc). Conversation turns themselves come from the
        LLM context at save() time, not from here."""
        self.system_events.append(
            {"kind": kind, "text": text, "ts": dt.datetime.now(dt.timezone.utc).isoformat()}
        )

    def save(self, context_messages=None) -> Path:
        """Writes the call record to disk. `context_messages` should be
        the LLMContext's `.messages` list at call-end (pass
        `context.get_messages_for_persistent_storage()` if your Pipecat
        version exposes it, otherwise `context.messages` directly)."""
        ended_at = dt.datetime.now(dt.timezone.utc).isoformat()
        record = {
            "call_id": self.call_id,
            "business": config.BUSINESS_NAME,
            "started_at": self.started_at,
            "ended_at": ended_at,
            "transcript": context_messages or [],
            "events": self.system_events,
        }
        out_path = Path(config.CALL_LOGS_DIR) / f"{self.call_id}.json"
        if out_path.exists():
            out_path = Path(config.CALL_LOGS_DIR) / (
                f"{self.call_id}-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')}.json"
            )
        try:
            out_path.write_text(json.dumps(record, indent=2, default=str), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001 - a logging failure must never crash a call
            import logging

            logging.getLogger("ai_calling_agent.call_logger").error(
                f"Failed to save call log for {self.call_id}: {exc}"
            )
        return out_path
