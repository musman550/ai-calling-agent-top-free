"""
utils/reliability.py
----------------------
A small, deliberately simple retry decorator for OUR OWN network calls
(Cal.com booking webhook, Twilio SMS/transfer REST calls) — the pieces
of code we fully control and can safely retry with backoff.

This does NOT wrap Pipecat's internal LLM/STT/TTS request handling —
that is maintained by the Pipecat team inside the services themselves,
and reaching into it with unverified retry logic would risk introducing
bugs rather than preventing them. If Groq's free tier rate-limits you
mid-call, the honest fix is either a paid key for that client or fewer
concurrent calls per key — not a home-made patch pretending otherwise.
"""

import asyncio
import functools
import logging

logger = logging.getLogger("ai_calling_agent.reliability")


def with_retry(max_attempts: int = 3, base_delay: float = 0.4):
    """Retries an async function with exponential backoff. Use this only
    on idempotent operations (booking POST, SMS send) — never wrap
    anything that could double-charge or double-book on a retry unless
    the endpoint itself is idempotent."""

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                except Exception as exc:  # noqa: BLE001
                    last_exc = exc
                    if attempt == max_attempts:
                        raise
                    delay = base_delay * (2 ** (attempt - 1))
                    logger.warning(
                        f"{func.__name__} failed (attempt {attempt}/{max_attempts}): "
                        f"{exc} — retrying in {delay:.1f}s"
                    )
                    await asyncio.sleep(delay)
            raise last_exc  # pragma: no cover

        return wrapper

    return decorator
