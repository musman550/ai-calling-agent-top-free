"""
utils/booking.py
------------------
Optional: send a captured booking (name, phone, date/time, reason) to a
Cal.com webhook (free self-hosted or free cloud tier) the moment the
agent confirms it with the caller.

Called from the `book_appointment` tool in utils/tools.py, which the LLM
triggers via structured function-calling once it has confirmed the
details with the caller. Kept in its own file so non-Python-savvy team
members can edit the payload shape without touching the voice pipeline.
"""

import json
import logging
import datetime as dt
import httpx

import config
from utils.reliability import with_retry

logger = logging.getLogger("ai_calling_agent.booking")


@with_retry(max_attempts=config.MAX_RETRY_ATTEMPTS, base_delay=config.RETRY_BASE_DELAY_SECONDS)
async def _post_booking(payload: dict):
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(config.CALCOM_WEBHOOK_URL, json=payload)
        resp.raise_for_status()
        return resp


async def send_booking(name: str, phone: str, preferred_time: str, reason: str = ""):
    """POSTs a booking request to the configured Cal.com webhook URL.

    Returns True on success, False otherwise (never raises — a failed
    booking webhook should not crash a live phone call).
    """
    if not config.CALCOM_WEBHOOK_URL:
        _record("booking", name, phone, f"{preferred_time} — {reason}", "saved locally (no webhook set)")
        return True

    payload = {
        "name": name,
        "phone": phone,
        "preferred_time": preferred_time,
        "reason": reason,
        "source": "ai_calling_agent",
        "business": config.BUSINESS_NAME,
    }

    try:
        await _post_booking(payload)
        logger.info(f"Booking sent for {name} at {preferred_time}")
        _record("booking", name, phone, f"{preferred_time} — {reason}", "sent to webhook")
    except Exception as exc:  # noqa: BLE001 - a failed webhook must not crash a live call
        logger.error(f"Booking webhook failed after retries: {exc}")
        _record("booking", name, phone, f"{preferred_time} — {reason}", "webhook FAILED - saved locally")
    return True


def _record(kind: str, name: str, phone: str, detail: str, status: str = "saved"):
    """Every booking/message is ALSO stored locally (call_logs/records.jsonl), so nothing is lost
    when no calendar webhook is configured or the webhook is down. Shown in the dashboard."""
    rec = {"kind": kind, "ts": dt.datetime.now(dt.timezone.utc).isoformat(), "name": name,
           "phone": phone, "detail": detail, "status": status}
    with open(config.CALL_LOGS_DIR / "records.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def record_message(name: str, phone: str, message: str):
    _record("message", name, phone, message)
