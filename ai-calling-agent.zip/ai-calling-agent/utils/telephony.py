"""
utils/telephony.py
--------------------
Warm-transfers a LIVE Twilio call to a human number.

Unlike the older, hand-rolled approach of running your own FastAPI
webhook + WebSocket server, this relies on Pipecat's own development
runner to answer the call and give you the provider's call id directly
via `runner_args.call_data.call_id` (see bot.py) — so there's no custom
webhook code here to get wrong. This file only does the one thing that
genuinely needs the Twilio REST API: redirecting an already-connected
call.
"""

import asyncio
import logging

from twilio.rest import Client as TwilioClient
from twilio.twiml.voice_response import VoiceResponse, Dial

import config

logger = logging.getLogger("ai_calling_agent.telephony")


def _twilio_client() -> TwilioClient:
    return TwilioClient(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)


async def transfer_call(call_sid: str, reason: str = "") -> bool:
    """Redirects the live call identified by `call_sid` to
    config.HUMAN_TRANSFER_NUMBER. Returns True on success.

    Safe to call from an async tool handler — this makes a quick
    synchronous Twilio REST call under the hood (the official Twilio
    Python SDK doesn't have an async client), which is fine here since
    it's a single fast HTTP request, not something in the audio path.
    """
    if not config.HUMAN_TRANSFER_NUMBER:
        logger.warning("Transfer requested but HUMAN_TRANSFER_NUMBER is not set in .env")
        return False
    if not call_sid:
        logger.error("Transfer requested but no call_sid was available for this call.")
        return False
    if not (config.TWILIO_ACCOUNT_SID and config.TWILIO_AUTH_TOKEN):
        logger.error("Transfer requested but Twilio credentials are not set in .env")
        return False

    twiml = VoiceResponse()
    twiml.say("Connecting you now, please hold.")
    dial = Dial()
    dial.number(config.HUMAN_TRANSFER_NUMBER)
    twiml.append(dial)

    try:
        await asyncio.to_thread(lambda: _twilio_client().calls(call_sid).update(twiml=str(twiml)))
        logger.info(f"Call {call_sid} transferred to {config.HUMAN_TRANSFER_NUMBER} — reason: {reason}")
        return True
    except Exception as exc:  # noqa: BLE001 - a failed transfer must not crash the call
        logger.error(f"Transfer failed for call {call_sid}: {exc}")
        return False
