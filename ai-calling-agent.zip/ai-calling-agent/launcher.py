"""
launcher.py — starts the REAL calling agent with one command.

  1. Opens a free public tunnel (Cloudflare quick tunnel, no signup) so Twilio can reach you
  2. Points your Twilio number's voice webhook at it (inbound calls answered automatically)
  3. Starts the real-time voice engine (bot.py, Pipecat + Groq)
  4. Starts the dashboard + API on http://localhost:8000 (outbound "Call now", call history)

Keys are read from .env on THIS machine (server-side) — they never go to the browser.
Options: --no-tunnel --public-host your.domain.com   (if you already have a public domain)
"""
import os, re, sys, time, atexit, socket, platform, subprocess, threading, urllib.request, urllib.error, argparse, json, glob
from pathlib import Path
from dotenv import load_dotenv

load_dotenv(override=True)
BASE = Path(__file__).resolve().parent
ENGINE_PORT, DASH_PORT = 7860, 8000
procs = []
LAST_CALL = [0.0]
atexit.register(lambda: [p.terminate() for p in procs if p.poll() is None])


def start_tunnel():
    win = platform.system() == "Windows"
    exe = BASE / ("cloudflared.exe" if win else "cloudflared")
    if not exe.exists():
        if not win:
            sys.exit("Install cloudflared (https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/) or use --public-host.")
        print("Downloading cloudflared (one time, ~30 MB)...")
        urllib.request.urlretrieve("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe", exe)
    p = subprocess.Popen([str(exe), "tunnel", "--url", f"http://localhost:{ENGINE_PORT}"], stderr=subprocess.PIPE, text=True)
    procs.append(p)
    t0 = time.time()
    while time.time() - t0 < 45:
        line = p.stderr.readline()
        m = re.search(r"https://([a-z0-9-]+\.trycloudflare\.com)", line or "")
        if m:
            threading.Thread(target=lambda: [None for _ in p.stderr], daemon=True).start()
            return m.group(1)
    sys.exit("Tunnel did not start. Check your internet connection.")


def twilio_client():
    from twilio.rest import Client
    return Client(os.getenv("TWILIO_ACCOUNT_SID", ""), os.getenv("TWILIO_AUTH_TOKEN", ""))


def point_twilio_number(host):
    num = os.getenv("TWILIO_PHONE_NUMBER", "").strip()
    if not (num and os.getenv("TWILIO_ACCOUNT_SID") and os.getenv("TWILIO_AUTH_TOKEN")):
        print("! Twilio not fully set in .env — inbound webhook NOT configured.")
        return False
    try:
        nums = twilio_client().incoming_phone_numbers.list(phone_number=num)
        if not nums:
            print(f"! {num} not found in this Twilio account.")
            return False
        nums[0].update(voice_url=f"https://{host}/", voice_method="POST")
        print(f"✓ Twilio number {num} now answers with your agent (inbound ready).")
        return True
    except Exception as e:
        print(f"! Could not update Twilio webhook: {e}")
        return False


def engine_up():
    try:
        socket.create_connection(("127.0.0.1", ENGINE_PORT), timeout=0.4).close()
        return True
    except OSError:
        return False


def build_app(host):
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.staticfiles import StaticFiles
    from pydantic import BaseModel

    app = FastAPI(title="AI Calling Agent Dashboard API")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

    class Call(BaseModel):
        to: str

    @app.get("/api/status")
    def status():
        return {"public_host": host, "twilio": bool(os.getenv("TWILIO_ACCOUNT_SID") and os.getenv("TWILIO_PHONE_NUMBER")),
                "groq": bool(os.getenv("GROQ_API_KEY")), "engine": ENGINE_PORT, "engine_up": engine_up(),
                "models": {k: os.getenv(v) for k, v in (("llm", "GROQ_LLM_MODEL"), ("stt", "GROQ_STT_MODEL"), ("tts", "GROQ_TTS_MODEL"))}}

    @app.post("/api/call")
    def call(c: Call):
        if not re.fullmatch(r"\+\d{8,15}", c.to):
            raise HTTPException(400, "Use international format, e.g. +923001234567")
        if not (os.getenv("TWILIO_ACCOUNT_SID") and os.getenv("TWILIO_AUTH_TOKEN") and os.getenv("TWILIO_PHONE_NUMBER")):
            raise HTTPException(400, "Fill TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER in .env")
        if time.time() - LAST_CALL[0] < 4:
            raise HTTPException(429, "Wait a few seconds between calls (double-click protection).")
        if not engine_up():
            raise HTTPException(503, "Voice engine is not running yet — wait a few seconds and retry.")
        LAST_CALL[0] = time.time()
        twiml = f'<Response><Connect><Stream url="wss://{host}/ws"/></Connect></Response>'
        try:
            r = twilio_client().calls.create(to=c.to, from_=os.getenv("TWILIO_PHONE_NUMBER"), twiml=twiml)
        except Exception as e:
            raise HTTPException(502, f"Twilio refused the call: {e}")
        return {"ok": True, "sid": r.sid, "status": r.status}

    @app.get("/api/logs")
    def logs():
        out = []
        for f in sorted(glob.glob(str(BASE / "call_logs" / "*.json")), key=os.path.getmtime, reverse=True)[:20]:
            try:
                d = json.load(open(f, encoding="utf-8"))
                turns = [m for m in d.get("transcript", []) if m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str)]
                out.append({"call_id": d.get("call_id"), "ended_at": d.get("ended_at"), "turns": len(turns),
                            "events": [e["text"] for e in d.get("events", [])][:5]})
            except Exception:
                pass
        return out

    @app.get("/api/records")
    def records():
        out = []
        p = BASE / "call_logs" / "records.jsonl"
        if p.exists():
            for line in p.read_text(encoding="utf-8").splitlines()[-20:]:
                try:
                    out.append(json.loads(line))
                except Exception:
                    pass
        return out[::-1]

    app.mount("/", StaticFiles(directory=str(BASE / "static"), html=True), name="dash")
    return app


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-tunnel", action="store_true")
    ap.add_argument("--public-host", default="")
    a = ap.parse_args()
    if not os.getenv("GROQ_API_KEY") or "your_groq" in os.getenv("GROQ_API_KEY", ""):
        sys.exit("Put your real GROQ_API_KEY in .env first (console.groq.com/keys).")
    try:
        sys.path.insert(0, str(BASE))
        from utils.models import fetch_models, apply_models
        ids = fetch_models(os.environ["GROQ_API_KEY"])
        for n in apply_models(os.environ, ids):
            print("✓ Model auto-select:", n)
    except urllib.error.HTTPError as e:
        sys.exit("Groq rejected your key (HTTP %s). Paste a valid GROQ_API_KEY in .env." % e.code if e.code in (401, 403) else f"Groq error {e.code}")
    except Exception as e:
        print(f"! Could not verify models ({e}); continuing with .env values.")
    if not (os.getenv("TWILIO_ACCOUNT_SID") and os.getenv("TWILIO_AUTH_TOKEN")):
        print("! TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN missing in .env — real phone calls need them.")
    host = a.public_host if a.no_tunnel else start_tunnel()
    print(f"✓ Public address: https://{host}")
    point_twilio_number(host)
    procs.append(subprocess.Popen([sys.executable, "bot.py", "-t", "twilio", "--proxy", host, "--port", str(ENGINE_PORT)], cwd=BASE))
    for _ in range(60):
        if engine_up():
            break
        time.sleep(0.5)
    print("✓ Voice engine is ready" if engine_up() else "! Voice engine did not start — read the errors above.")
    print(f"✓ Dashboard: http://localhost:{DASH_PORT}   (Ctrl+C to stop everything)")
    import uvicorn
    uvicorn.run(build_app(host), host="127.0.0.1", port=DASH_PORT, log_level="warning")


if __name__ == "__main__":
    main()
