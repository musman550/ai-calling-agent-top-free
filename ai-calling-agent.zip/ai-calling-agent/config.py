"""
config.py
---------
Single place to control the agent's behaviour per client.

To run several clients from one codebase, duplicate this file per
client (e.g. configs/client_a.py) and point bot.py at the right one
via an environment variable — apni marzi, jo simpler lage for how
many clients you're running at once.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------
# Provider keys (loaded from .env — never hardcode real keys here)
# ---------------------------------------------------------------
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER", "")

CALCOM_WEBHOOK_URL = os.getenv("CALCOM_WEBHOOK_URL", "")

# ---------------------------------------------------------------
# Model selection — free-tier defaults, swap anytime.
# Faster/smaller models trade a little quality for lower latency and a
# higher free-tier rate limit; try llama-3.1-8b-instant for a client
# who needs very short, simple calls handled at maximum speed.
# ---------------------------------------------------------------
GROQ_LLM_MODEL = os.getenv("GROQ_LLM_MODEL", "llama-3.3-70b-versatile")
GROQ_STT_MODEL = os.getenv("GROQ_STT_MODEL", "whisper-large-v3-turbo")
GROQ_TTS_MODEL = os.getenv("GROQ_TTS_MODEL", "playai-tts")
GROQ_TTS_VOICE = os.getenv("GROQ_TTS_VOICE", "Fritz-PlayAI")

# Retry/backoff tuning for OUR OWN network calls (booking webhook, SMS) —
# see utils/reliability.py. Does not touch Pipecat's own STT/LLM/TTS calls.
MAX_RETRY_ATTEMPTS = int(os.getenv("MAX_RETRY_ATTEMPTS", "2"))
RETRY_BASE_DELAY_SECONDS = float(os.getenv("RETRY_BASE_DELAY_SECONDS", "0.5"))

# Number to warm-transfer a call to when the agent (or caller) requests a
# human. Leave blank to disable transfers (agent will take a message instead).
HUMAN_TRANSFER_NUMBER = os.getenv("HUMAN_TRANSFER_NUMBER", "")

# ---------------------------------------------------------------
# Business identity + knowledge (edit per client)
# ---------------------------------------------------------------
BUSINESS_NAME = os.getenv("BUSINESS_NAME", "Your Client's Business Name")

SYSTEM_PROMPT_PATH = BASE_DIR / "prompts" / "system_prompt.txt"


def load_system_prompt() -> str:
    """Loads the agent's personality + business knowledge from a text file
    so non-technical staff can update it without touching Python code."""
    if SYSTEM_PROMPT_PATH.exists():
        return SYSTEM_PROMPT_PATH.read_text(encoding="utf-8").replace(
            "{{BUSINESS_NAME}}", BUSINESS_NAME
        )
    return (
        f"You are a helpful, friendly phone receptionist for {BUSINESS_NAME}. "
        "Keep responses short and natural, like a real phone call."
    )


# ---------------------------------------------------------------
# Conversation behaviour tuning
# ---------------------------------------------------------------
GREETING_INSTRUCTION = (
    f"Start the call by briefly and warmly greeting the caller on behalf "
    f"of {BUSINESS_NAME}, then ask how you can help."
)

# ---------------------------------------------------------------
# Call logging
# ---------------------------------------------------------------
CALL_LOGS_DIR = BASE_DIR / "call_logs"
CALL_LOGS_DIR.mkdir(exist_ok=True)
