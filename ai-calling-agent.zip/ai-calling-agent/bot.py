"""
bot.py
------
The AI calling agent, built on Pipecat's official development runner.

This is the single entry point for BOTH the free browser demo (WebRTC,
$0 cost) and real phone calls (Twilio). Pipecat's runner answers the
connection, builds the right transport, and calls `bot(runner_args)` —
so there is no hand-rolled FastAPI/WebSocket bridging code here to get
wrong. That is the single biggest reliability upgrade in this version:
less custom plumbing means fewer places for a bug to hide.

RUNNING IT
----------
Free web demo (no telephony, no cost):
    python bot.py -t webrtc
    -> open the URL it prints (Pipecat's own prebuilt UI), click Connect,
       talk into your mic.
    -> Want your own branded page instead of Pipecat's? Open
       static/index.html directly in a browser once bot.py is
       running (see its comments for the one line to edit).

Real phone number (after you have a Twilio number + ngrok or similar):
    python bot.py -t twilio --proxy your-ngrok-domain.ngrok-free.app
    -> point that Twilio number's "A Call Comes In" webhook at
       https://your-ngrok-domain.ngrok-free.app/ (the runner serves the
       TwiML itself — no separate webhook file needed).

start_real.bat wraps both of these in a menu for Windows.

WHY THIS SHAPE: every import and pattern below is taken directly from
Pipecat's own current documentation (docs.pipecat.ai) — the runner
entry point, LLMContext + universal context aggregator, and
FunctionSchema-based tool calling are the officially documented 1.x
APIs, not guesses carried over from an older version. If a future
Pipecat release renames something, `python scripts/run_local_test.py`
plus the error message on `python bot.py` will point at exactly which
import needs a one-line update — the pipeline *shape* here stays correct.
"""

import uuid
import logging

from dotenv import load_dotenv

load_dotenv()  # no override: launcher.py may have auto-selected working models

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import LLMRunFrame, EndFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.runner import WorkerRunner
from pipecat.pipeline.worker import PipelineParams, PipelineWorker
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import LLMContextAggregatorPair
from pipecat.runner.types import RunnerArguments, WebSocketRunnerArguments
from pipecat.runner.utils import create_transport
from pipecat.transports.base_transport import TransportParams

from pipecat.services.groq.stt import GroqSTTService
from pipecat.services.groq.llm import GroqLLMService
from pipecat.services.groq.tts import GroqTTSService

import config
from utils.call_logger import CallLogger
from utils.tools import build_tools_schema, make_tool_handlers
from utils.telephony import transfer_call

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ai_calling_agent")


# ---------------------------------------------------------------
# Transport configuration — one entry per transport this bot supports.
# create_transport() picks the right one based on how the call arrived.
# ---------------------------------------------------------------
def _webrtc_params():
    return TransportParams(
        audio_in_enabled=True,
        audio_out_enabled=True,
        vad_analyzer=SileroVADAnalyzer(),
    )


def _twilio_params():
    # Imported lazily so a webrtc-only run never needs the twilio-specific
    # transport module installed/working.
    from pipecat.transports.websocket.fastapi import FastAPIWebsocketParams

    return FastAPIWebsocketParams(
        audio_in_enabled=True,
        audio_out_enabled=True,
        add_wav_header=False,
        vad_analyzer=SileroVADAnalyzer(),
    )


transport_params = {
    "webrtc": _webrtc_params,
    "twilio": _twilio_params,
}


async def run_pipeline(transport, call_id: str, on_transfer=None):
    """Builds and runs the full pipeline for one call/session."""
    # NOTE: each Groq service takes model/voice via its own `settings=`
    # object (its modern, non-deprecated API) rather than flat kwargs —
    # GroqTTSService in particular does NOT accept `model=`/`voice=`
    # directly, only `settings=GroqTTSService.Settings(model=..., voice=...)`.
    stt = GroqSTTService(
        api_key=config.GROQ_API_KEY,
        settings=GroqSTTService.Settings(model=config.GROQ_STT_MODEL),
    )
    llm = GroqLLMService(
        api_key=config.GROQ_API_KEY,
        settings=GroqLLMService.Settings(
            model=config.GROQ_LLM_MODEL,
            system_instruction=config.load_system_prompt(),
        ),
    )
    tts = GroqTTSService(
        api_key=config.GROQ_API_KEY,
        settings=GroqTTSService.Settings(
            model=config.GROQ_TTS_MODEL,
            voice=config.GROQ_TTS_VOICE,
        ),
    )

    call_logger = CallLogger(call_id=call_id)

    async def on_end_call():
        logger.info(f"[{call_id}] end_call tool triggered — wrapping up.")
        await task.queue_frames([EndFrame()])

    tool_handlers = make_tool_handlers(
        call_logger=call_logger,
        on_end_call=on_end_call,
        on_transfer=on_transfer,
    )
    for name, handler in tool_handlers.items():
        llm.register_function(name, handler)

    tools_schema = build_tools_schema()
    # The system prompt is set on the LLM service (system_instruction above);
    # putting it in the context as a "system" message is deprecated in Pipecat 1.9+.
    context = LLMContext(messages=[], tools=tools_schema)
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(context)

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    # Barge-in (caller interrupting the agent) is ON by default in Pipecat 1.x.
    task = PipelineWorker(
        pipeline,
        params=PipelineParams(
            enable_metrics=True,
            enable_usage_metrics=True,
        ),
    )

    saved = []

    def _save_and_close():
        if saved:  # never write the same call twice
            return
        saved.append(1)
        try:
            path = call_logger.save(context_messages=context.messages)
            logger.info(f"[{call_id}] Call log saved -> {path}")
        except Exception:  # noqa: BLE001 - logging must never break shutdown
            logger.exception(f"[{call_id}] Failed to save call log.")

    @transport.event_handler("on_client_connected")
    async def on_client_connected(_transport, _client):
        logger.info(f"[{call_id}] Caller connected.")
        context.add_message({"role": "user", "content": config.GREETING_INSTRUCTION})
        await task.queue_frames([LLMRunFrame()])

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(_transport, _client):
        logger.info(f"[{call_id}] Caller disconnected.")
        _save_and_close()
        await task.queue_frames([EndFrame()])

    runner = WorkerRunner(handle_sigint=False)
    await runner.add_workers(task)
    try:
        await runner.run()
    except Exception:
        # A pipeline-level crash should still leave a call log to debug
        # from, instead of silently vanishing.
        logger.exception(f"[{call_id}] Pipeline crashed.")
        _save_and_close()
        raise


async def bot(runner_args: RunnerArguments):
    """Official Pipecat entry point — called once per session by the
    development runner (and, unchanged, by Pipecat Cloud if you deploy
    there later)."""
    transport = await create_transport(runner_args, transport_params)

    call_id = str(uuid.uuid4())
    on_transfer = None

    # For a real Twilio call, the runner exposes the provider's call id
    # (Twilio's CallSid) directly — no custom webhook parsing needed.
    if isinstance(runner_args, WebSocketRunnerArguments) and runner_args.call_data:
        call_sid = getattr(runner_args.call_data, "call_id", None)
        if call_sid:
            call_id = call_sid

            async def on_transfer(reason: str):  # noqa: F811 - intentional shadow, call-scoped
                return await transfer_call(call_sid, reason)

    await run_pipeline(transport, call_id=call_id, on_transfer=on_transfer)


if __name__ == "__main__":
    from pipecat.runner.run import main

    main()
