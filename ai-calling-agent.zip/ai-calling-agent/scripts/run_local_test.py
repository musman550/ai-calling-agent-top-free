"""
scripts/run_local_test.py
---------------------------
Run this FIRST, before anything else, every time you set up a new
client's .env file. It checks that the Groq key works for STT, LLM,
and TTS — three tiny real API calls, no phone/browser needed — so you
catch a bad or missing key in seconds instead of mid-demo.

Usage:
    python scripts/run_local_test.py
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import config  # noqa: E402


def check_llm():
    from groq import Groq

    client = Groq(api_key=config.GROQ_API_KEY)
    resp = client.chat.completions.create(
        model=config.GROQ_LLM_MODEL,
        messages=[{"role": "user", "content": "Say 'ok' and nothing else."}],
        max_tokens=5,
    )
    print("  LLM  OK ->", resp.choices[0].message.content.strip())


def check_stt():
    # A tiny 1-second silent WAV is enough to confirm the endpoint + key work.
    import io
    import wave

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(16000)
        wf.writeframes(b"\x00\x00" * 16000)
    buf.seek(0)
    buf.name = "test.wav"

    from groq import Groq

    client = Groq(api_key=config.GROQ_API_KEY)
    resp = client.audio.transcriptions.create(
        model=config.GROQ_STT_MODEL,
        file=buf,
    )
    print("  STT  OK -> (silent clip transcribed with no error)")


def check_tts():
    from groq import Groq

    client = Groq(api_key=config.GROQ_API_KEY)
    resp = client.audio.speech.create(
        model=config.GROQ_TTS_MODEL,
        voice=config.GROQ_TTS_VOICE,
        input="This is a test.",
    )
    print("  TTS  OK -> audio bytes received:", len(resp.read()) > 0)


def main():
    if not config.GROQ_API_KEY:
        print("❌ GROQ_API_KEY is not set. Copy .env.example to .env and add your key.")
        print("   Get a free key: https://console.groq.com/keys")
        return

    print(f"Testing Groq key for business: {config.BUSINESS_NAME}\n")
    try:
        from utils.models import fetch_models, apply_models
        import os
        for n in apply_models(os.environ, fetch_models(config.GROQ_API_KEY)):
            print("  auto-select:", n)
        config.GROQ_LLM_MODEL, config.GROQ_STT_MODEL = os.environ["GROQ_LLM_MODEL"], os.environ["GROQ_STT_MODEL"]
        config.GROQ_TTS_MODEL = os.environ.get("GROQ_TTS_MODEL", config.GROQ_TTS_MODEL)
        config.GROQ_TTS_VOICE = os.environ.get("GROQ_TTS_VOICE", config.GROQ_TTS_VOICE)
    except Exception as exc:
        print(f"  could not list models: {exc}")
    checks = [("LLM", check_llm), ("STT", check_stt), ("TTS", check_tts)]
    for name, fn in checks:
        try:
            fn()
        except Exception as exc:  # noqa: BLE001
            print(f"  {name}  FAILED -> {exc}")

    print("\nIf all three show OK, you're ready to run `python bot.py -t webrtc`.")


if __name__ == "__main__":
    main()
