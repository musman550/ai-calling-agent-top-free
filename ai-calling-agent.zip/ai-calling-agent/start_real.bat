@echo off
REM start_real.bat - launches the REAL calling agent (voice engine + tunnel + dashboard)
cd /d "%~dp0"
python -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul
if errorlevel 1 (
    echo Python 3.11 or newer is required. Install it from python.org and tick "Add Python to PATH".
    pause
    exit /b 1
)
if not exist "venv\Scripts\activate.bat" (
    python -m venv venv
    if errorlevel 1 (
        echo Could not create the virtual environment.
        pause
        exit /b 1
    )
)
call venv\Scripts\activate.bat
echo Installing/Updating dependencies...
pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo Install failed. Check your internet connection and run this again.
    pause
    exit /b 1
)
if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo.
    echo Fill GROQ_API_KEY and TWILIO_* in the .env file that just opened, save it, then run this again.
    notepad .env
    pause
    exit /b 0
)
start "" cmd /c "timeout /t 20 >nul & start http://localhost:8000"
python launcher.py
echo.
echo The agent stopped. Read any error above.
pause
