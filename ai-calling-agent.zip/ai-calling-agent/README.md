# AI Calling Agent — Free-Tier Starter Kit (v3)
### For [Your Agency Name] — Client-Ready, BYOK (Bring Your Own Key) Model

A production-shaped phone-answering / AI calling agent built on
**Pipecat's official development runner** — the same framework and
patterns documented at docs.pipecat.ai, not a hand-rolled server. Every
client brings their own free Groq API key, so **your agency's running
cost stays $0**.

**v3 changed the foundation.** Earlier drafts of this project hand-built
a custom FastAPI + WebSocket server to bridge Twilio and browser audio.
That code used API patterns that don't match the Pipecat version pip
actually installs today (1.x), which is what caused the setup errors
you hit. This version instead uses Pipecat's own **runner** —
`pipecat.runner.run.main()` — which answers WebRTC and Twilio
connections for you using code the Pipecat team maintains and tests.
Less custom plumbing = fewer places for a bug to hide. Every import and
pattern in `bot.py` is taken directly from Pipecat's current docs.

---

## 1. Kaise kaam karta hai (Quick Urdu/English overview)

- Yeh agent phone call attend karta hai (ya browser demo mein chalta
  hai), caller ki baat sunta hai (Speech-to-Text), samajh kar jawab
  sochta hai (LLM), aur phir bolta hai (Text-to-Speech) — real-time,
  natural conversation ki tarah, interruptions (barge-in) ke saath.
- **Aap sirf code deliver karte hain.** Har client apni khud ki free
  Groq API key `.env` mein daalta hai. Aapki agency ka $0 running cost
  hai.
- Agent ab proper tool-calling use karta hai (book appointment, transfer
  to human, take a message, end call) — keyword-guessing nahi.
- Phone number/telephony (real PSTN call) ka ek hi hissa hai jahan asal
  duniya mein thoda paisa lagta hai — "Telephony Reality Check" section
  neeche.

---

## 2. v4 — bugs found and fixed by actually running the code

| Bug | Where | Fix |
|---|---|---|
| `model_not_found` (404) killed every call | hard-coded model names | `utils/models.py` asks Groq which models **your key** can use and picks automatically — no more guessing a name that isn't on your plan |
| A failed booking/message was lost forever if no Cal.com webhook was set | `utils/booking.py` | every booking/message is now also appended to `call_logs/records.jsonl` and shown in the dashboard, even with no webhook |
| Agent could say goodbye twice, or keep talking after a transfer | `utils/tools.py` | `end_call`/successful `transfer_to_human` now tell the LLM not to generate another reply (`run_llm=False`) |
| A live call froze if Cloudflare's tunnel process filled its output buffer | `launcher.py` | tunnel output is now drained continuously in the background |
| Dashboard's outbound-call API was reachable from other machines on the network | `launcher.py` | now bound to `127.0.0.1` only — outbound calling is local-machine-only by design |
| Double-clicking "Call now" could fire two Twilio calls | `launcher.py` | 4-second cooldown + a check that the voice engine is actually up before dialing |
| A call's Twilio REST update briefly froze the whole event loop (audio glitch for every other caller) | `utils/telephony.py` | moved to a background thread (`asyncio.to_thread`) |
| Call log timestamps used a deprecated, timezone-less API | `utils/call_logger.py` | switched to timezone-aware UTC timestamps |
| A crashed pipeline could save the same call's log twice | `bot.py` | guarded so a call log is only ever written once |
| `.env` (with real API keys) had no `.gitignore` — easy to accidentally commit to a public repo | new `.gitignore` | `.env`, call logs, and `venv/` are now excluded by default |
| n8n's per-call memory grew forever on a long-running server | `static/index.html` (workflow export) | oldest call's memory is dropped once more than 50 calls are in flight |

## 3. What was actually wrong before (so you know it's fixed)

| Symptom you saw | Real cause | Fixed by |
|---|---|---|
| `does not provide the extra 'twilio'` | `pipecat-ai[twilio]` isn't a real pip extra — Twilio support comes from the separate `twilio` package | `requirements.txt` now only lists real extras (`silero`, `groq`, `runner`, `webrtc`) |
| `Invalid API Key (401)` on LLM/STT/TTS | `.env` still had the placeholder text instead of a real Groq key | Not a code bug — open `.env`, paste your real key from console.groq.com/keys, re-run |
| `WebRTC disabled (install pipecat-ai[webrtc])`, `GroqTTSService` wrong kwargs, deprecated Pipecat calls | found by actually installing Pipecat 1.12.0 and running the bot end-to-end with a simulated WebRTC caller | `webrtc` extra added, TTS uses `settings=`, modern `PipelineWorker`/`WorkerRunner`, `pipecat-ai<2.0` pinned |
| (latent, not yet hit) import errors in `bot.py` | earlier code used Pipecat's old 0.0.x API (`LLMUserResponseAggregator`, a hand-built FastAPI/Twilio bridge) against the 1.12.0 version pip actually installs | `bot.py` rewritten against Pipecat's current documented 1.x API and official runner |

---

## 4. Free-Tier Stack

| Piece | Provider | Free tier (2026) | Notes |
|---|---|---|---|
| Speech-to-Text | Groq Whisper (`whisper-large-v3-turbo`) | Permanent free tier, no card | |
| LLM brain | Groq (`llama-3.3-70b-versatile`) | Free tier, rate-limited, no card | Swap in `.env` any time |
| Text-to-Speech | Groq PlayAI TTS | Free tier, rate-limited | |
| Voice activity detection | Silero VAD (local) | 100% free, runs on CPU | |
| Web demo (no phone) | Pipecat's prebuilt WebRTC UI, or your own branded page | 100% free, zero telephony cost | Best for client pitches |
| Real phone number + PSTN calls | Twilio | $15 one-time trial credit, then pay-as-you-go | **Not free forever** — see below |
| Booking | Cal.com | Free self-hosted or free cloud tier | |

### Telephony Reality Check (batao client ko honestly)
Koi bhi service jo **real phone number** par calls answer karti hai ka
connection PSTN (phone network) se hota hai, aur carriers per-minute
charge karte hain — yeh cost duniya mein kahin bhi $0 nahi ho sakti.
Free tools sirf **code aur AI processing** ko free bana sakte hain,
phone line ko nahin.
- Demo/pitch ke liye: `python bot.py -t webrtc` — bilkul free.
- Production real number ke liye: Twilio ka $15 trial se start karein;
  cost transparently client ke apne account par jaye.

---

## 5. Folder Structure

```
ai_calling_agent/
├── README.md
├── requirements.txt
├── .env.example
├── start_real.bat                    ← Windows one-click launcher (real calls)
├── launcher.py                        ← tunnel + Twilio webhook + voice engine + dashboard API
├── config.py                     ← all settings, one place
├── bot.py                          ← THE agent (Pipecat official runner entry point)
├── prompts/
│   └── system_prompt.txt            ← agent's personality + business knowledge
├── .gitignore                    ← keeps .env, call logs and venv out of git
├── utils/
│   ├── models.py                     ← asks Groq which models YOUR key can use, picks automatically
│   ├── tools.py                      ← structured tool-calling (book/transfer/message/hangup)
│   ├── telephony.py                   ← warm call transfer via Twilio REST
│   ├── call_logger.py                  ← per-call JSON transcript + tool-event log
│   ├── booking.py                       ← Cal.com booking webhook (with retry)
│   ├── sms_followup.py                   ← optional post-call SMS via Twilio
│   └── reliability.py                     ← retry decorator for our own network calls
├── static/
│   └── index.html                    ← standalone control-center page (double-click or host as-is)
├── scripts/
│   └── run_local_test.py                    ← sanity-checks your Groq key
└── call_logs/                                ← JSON call reports land here
```

---

## 6. Local Setup

### Windows — one-click way
Double-click `start_real.bat`. It creates a virtual environment, installs
dependencies, prompts you to fill in `.env` on first run, tests your
Groq key, then lets you choose the free web demo or real Twilio calls.

### Manual way (any OS)
```bash
cd ~/Desktop/ai_calling_agent
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then paste your real Groq key inside
python scripts/run_local_test.py

# Free web demo:
python bot.py -t webrtc
# -> open the URL it prints, click Connect, talk.
# -> or just double-click static/index.html: a standalone page where
#    you paste a Groq key and talk to the agent in the browser (no server).

# Real phone number (after Twilio number + ngrok/similar tunnel):
python bot.py -t twilio --proxy your-ngrok-domain.ngrok-free.app
# -> point Twilio's "A Call Comes In" webhook at
#    https://your-ngrok-domain.ngrok-free.app/
```

---

## 7. Premium Features

- **Barge-in / interruption handling** — native Pipecat capability.
- **Structured tool-calling** (`utils/tools.py`) — `book_appointment`,
  `transfer_to_human`, `take_message`, `end_call`, defined with
  Pipecat's own `FunctionSchema`/`ToolsSchema`, the same mechanism
  Vapi/Retell/Bland use, working against Groq's tool-calling support.
- **True warm call transfer** (`utils/telephony.py`) — redirects the
  *live* Twilio call via the REST API using the CallSid Pipecat's
  runner exposes directly (`runner_args.call_data.call_id`) — no
  custom webhook parsing required.
- **Retry with backoff** on our own network calls (`utils/reliability.py`)
  — the Cal.com booking webhook and Twilio SMS/transfer calls retry
  automatically; a single flaky request never breaks the call.
- **Per-call JSON log** (`utils/call_logger.py`) — full transcript
  (read straight from Pipecat's own conversation context, so it can
  never drift from what was actually said) plus every tool action taken.
- **Editable business knowledge** (`prompts/system_prompt.txt`) — swap
  services, hours, FAQ, tone per client without touching code.
- **Control-center page** (`static/index.html`) — one standalone file, no server: settings/keys UI, live voice agent, tool-event log, latency stats and Auto-Heal diagnostics. Session-only (nothing saved; refresh clears). Host it as-is on Vercel or GitHub Pages.
- **Provider-agnostic core** — swap Groq → OpenAI/Deepgram/ElevenLabs
  later by changing three service constructors in `bot.py`.

## 8. Where this stands vs. Vapi / Retell / Bland (honest comparison)

| | Vapi / Retell / Bland | This scaffold |
|---|---|---|
| Per-minute AI cost | $0.05–$0.31/min, billed to you | $0 (Groq free tier); only PSTN carrier cost, billed to the client's own Twilio account |
| Structured tool-calling | Yes | Yes |
| Warm transfer | Yes | Yes |
| Call transcripts/logs | Yes | Yes (JSON, local) |
| Latency | 600–1,400ms depending on platform | Groq's inference is among the fastest available — **measure your own** real end-to-end latency (network + Twilio overhead matter too) rather than trusting any vendor's marketing number, this one included |
| No-code builder, dashboard, SLA/support | Yes (that's what you're paying for) | Not included — this is code you own and can extend |

Honest pitch to clients: *"same core capabilities — tool-calling,
transfers, call logs — at $0 AI cost, because you own the code instead
of renting theirs."* Don't claim it's faster or more reliable than
every competitor in every scenario without measuring — that would not
be honest, and it isn't necessary to make a strong pitch.

## 9. Suggested next steps (not yet built)
- Real-time call dashboard (Next.js, ties into your existing website repo)
- Sentiment/analytics pass on transcripts (a second cheap LLM call per call)
- Multi-language auto-detect (Whisper supports 90+ languages — just wire it up)
- Outbound calling with voicemail (AMD) detection — a legitimate feature
  but deliberately left out of this version rather than shipped
  half-verified; ask for it as a follow-up and it'll get the same
  careful, documented treatment as everything above.

---

**If something still doesn't import:** run
`python -c "import pipecat; print(pipecat.__version__)"` and check
`https://docs.pipecat.ai` for that exact version — Pipecat ships
frequent releases, and this is the fastest way to catch a renamed
import before it becomes a live-call problem.
